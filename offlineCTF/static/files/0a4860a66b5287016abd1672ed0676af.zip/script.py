import struct

f = open('important_file', 'rb')
data = f.read()
f.close()
padding = 4 - len(data) % 4
if padding != 0:
    data = data + "\x00" * padding
result = []
blocks = struct.unpack('I' * (len(data)/4), data)
for block in blocks:
    result += [block ^ block >> 8]

output = ''
for block in result:
    output += struct.pack('I', block)

f = open('encrypted','wb')
f.write(output)
f.close()